#define USRINFO "./userinfo"

#define WORK_HOME "/home/ftp"

#define MAX_LOGIN 500

#define CONTROL_PORT 21
